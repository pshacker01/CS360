package com.example.cs360project2_mccormack;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private Button loginButton, createAccountButton;

    private DatabaseHelper dbHelper;

    private static final int SMS_PERMISSION_CODE = 101;
    private boolean pendingOpenGridAfterPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Disable Login until both fields have text
        TextWatcher enabler = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String u = usernameInput.getText().toString().trim();
                String p = passwordInput.getText().toString().trim();
                loginButton.setEnabled(!u.isEmpty() && !p.isEmpty());
            }
            @Override public void afterTextChanged(Editable s) {}
        };
        usernameInput.addTextChangedListener(enabler);
        passwordInput.addTextChangedListener(enabler);

        // Enforce DB-backed login
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHelper.checkUser(username, password)) {
                pendingOpenGridAfterPermission = true;
                requestSmsPermissionIfNeeded();
            } else {
                Toast.makeText(this, "Invalid login. Create an account first.", Toast.LENGTH_SHORT).show();
            }
        });

        // Create account
        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter username and password to create an account.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = dbHelper.addUser(username, password);
            if (created) {
                Toast.makeText(this, "Account created. You can log in now.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "User already exists.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ---- SMS permission flow ----
    private void requestSmsPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            if (pendingOpenGridAfterPermission) {
                pendingOpenGridAfterPermission = false;
                openDataGrid();
            }
            return;
        }
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. App will work without SMS.", Toast.LENGTH_SHORT).show();
            }
            if (pendingOpenGridAfterPermission) {
                pendingOpenGridAfterPermission = false;
                openDataGrid();
            }
        }
    }

    private void openDataGrid() {
        Intent intent = new Intent(MainActivity.this, DataGridActivity.class);
        startActivity(intent);
    }
}
