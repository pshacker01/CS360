package com.example.cs360project2_mccormack;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataGridActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DataAdapter adapter;
    private ArrayList<DataItem> dataList;
    private DatabaseHelper dbHelper;

    private EditText editTitle, editDescription, editQuantity;
    private Button buttonAdd;
    private static final int SMS_PERMISSION_CODE = 100;
    private static final int LOW_THRESHOLD = 0; // trigger at zero for low inventory

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        dbHelper = new DatabaseHelper(this);
        dataList = dbHelper.getAllData();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new DataAdapter(dataList, new DataAdapter.OnRowActions() {
            @Override
            public void onDelete(DataItem item) {
                dbHelper.deleteData(item.getId());
                refresh();
            }

            @Override
            public void onIncrement(DataItem item) {
                int newQty = item.getQuantity() + 1;
                dbHelper.updateQuantity(item.getId(), newQty);
                refresh();
            }

            @Override
            public void onDecrement(DataItem item) {
                int newQty = Math.max(0, item.getQuantity() - 1); // never negative
                dbHelper.updateQuantity(item.getId(), newQty);
                refresh();
                if (newQty <= LOW_THRESHOLD) maybeSendLowInventorySMS(item);
            }
        });
        recyclerView.setAdapter(adapter);

        editTitle = findViewById(R.id.editTitle);
        editDescription = findViewById(R.id.editDescription);
        editQuantity = findViewById(R.id.editQuantity);
        buttonAdd = findViewById(R.id.buttonAdd);

        checkSmsPermission(); // ask early so alerts can work

        buttonAdd.setOnClickListener(v -> {
            String title = editTitle.getText().toString().trim();
            String description = editDescription.getText().toString().trim();
            String qtyStr = editQuantity.getText().toString().trim();
            int qty = qtyStr.isEmpty() ? 0 : Integer.parseInt(qtyStr);

            if (!title.isEmpty() && !description.isEmpty()) {
                dbHelper.addData(title, description, qty);
                editTitle.setText("");
                editDescription.setText("");
                editQuantity.setText("");
                refresh();
                if (qty <= LOW_THRESHOLD) {
                    maybeSendLowInventorySMS(new DataItem(-1, title, description, qty));
                }
            } else {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refresh() {
        dataList.clear();
        dataList.addAll(dbHelper.getAllData());
        adapter.notifyDataSetChanged();
    }

    // --- SMS permission & alerts ---
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications disabled.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void maybeSendLowInventorySMS(DataItem item) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return; // respect user choice
        }
        try {
            String msg = "Low inventory alert: \"" + item.getTitle() + "\" has reached quantity 0.";
            // Replace with a real/test number during local testing
            SmsManager.getDefault().sendTextMessage("1234567890", null, msg, null, null);
            Toast.makeText(this, "Low-inventory SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
