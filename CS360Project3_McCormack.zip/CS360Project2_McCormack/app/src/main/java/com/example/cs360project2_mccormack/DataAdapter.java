package com.example.cs360project2_mccormack;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    public interface OnRowActions {
        void onDelete(DataItem item);
        void onIncrement(DataItem item);
        void onDecrement(DataItem item);
    }

    private final ArrayList<DataItem> dataList;
    private final OnRowActions actions;

    public DataAdapter(ArrayList<DataItem> dataList, OnRowActions actions) {
        this.dataList = dataList;
        this.actions = actions;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        DataItem item = dataList.get(position);
        h.textTitle.setText(item.getTitle());
        h.textDescription.setText(item.getDescription());
        h.textQuantity.setText("Qty: " + item.getQuantity());

        h.buttonDelete.setOnClickListener(v -> actions.onDelete(item));
        h.buttonIncrement.setOnClickListener(v -> actions.onIncrement(item));
        h.buttonDecrement.setOnClickListener(v -> actions.onDecrement(item));
    }

    @Override
    public int getItemCount() { return dataList.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle, textDescription, textQuantity;
        Button buttonIncrement, buttonDecrement, buttonDelete;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.textTitle);
            textDescription = itemView.findViewById(R.id.textDescription);
            textQuantity = itemView.findViewById(R.id.textQuantity);
            buttonIncrement = itemView.findViewById(R.id.buttonIncrement);
            buttonDecrement = itemView.findViewById(R.id.buttonDecrement);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
