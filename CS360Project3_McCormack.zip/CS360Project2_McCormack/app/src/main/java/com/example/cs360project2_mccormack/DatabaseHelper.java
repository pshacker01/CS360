package com.example.cs360project2_mccormack;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "project2.db";
    private static final int DB_VERSION = 2; // bump version to add quantity
    private static final String TABLE_USERS = "users";
    private static final String TABLE_DATA = "data";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT, " +
                "password TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_DATA + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT, " +
                "description TEXT, " +
                "quantity INTEGER DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_DATA + " RENAME TO data_old");
            db.execSQL("CREATE TABLE " + TABLE_DATA + " (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "title TEXT, " +
                    "description TEXT, " +
                    "quantity INTEGER DEFAULT 0)");
            db.execSQL("INSERT INTO " + TABLE_DATA + " (title, description, quantity) " +
                    "SELECT title, description, 0 FROM data_old");
            db.execSQL("DROP TABLE data_old");
        }
    }

    // Users
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_USERS + " WHERE username=?",
                new String[]{username});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        if (exists) return false;

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        db.insert(TABLE_USERS, null, values);
        return true;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_USERS + " WHERE username=? AND password=?",
                new String[]{username, password});
        boolean ok = cursor.moveToFirst();
        cursor.close();
        return ok;
    }

    // Data CRUD
    public void addData(String title, String description, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("title", title);
        v.put("description", description);
        v.put("quantity", quantity);
        db.insert(TABLE_DATA, null, v);
    }

    public ArrayList<DataItem> getAllData() {
        ArrayList<DataItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, title, description, quantity FROM " + TABLE_DATA + " ORDER BY id DESC", null);
        while (c.moveToNext()) {
            list.add(new DataItem(
                    c.getInt(0),
                    c.getString(1),
                    c.getString(2),
                    c.getInt(3)
            ));
        }
        c.close();
        return list;
    }

    public void deleteData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_DATA, "id=?", new String[]{String.valueOf(id)});
    }

    public void updateQuantity(int id, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("quantity", newQuantity);
        db.update(TABLE_DATA, v, "id=?", new String[]{String.valueOf(id)});
    }
}
